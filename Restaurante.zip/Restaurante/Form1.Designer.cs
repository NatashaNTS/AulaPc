﻿namespace Restaurante
{
    partial class Pedidos
    {
        /// <summary>
        /// Variável de designer necessária.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Limpar os recursos que estão sendo usados.
        /// </summary>
        /// <param name="disposing">true se for necessário descartar os recursos gerenciados; caso contrário, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Código gerado pelo Windows Form Designer

        /// <summary>
        /// Método necessário para suporte ao Designer - não modifique 
        /// o conteúdo deste método com o editor de código.
        /// </summary>
        private void InitializeComponent()
        {
            this.lblMesa = new System.Windows.Forms.Label();
            this.txtMesa = new System.Windows.Forms.TextBox();
            this.lblPedidos = new System.Windows.Forms.Label();
            this.lblQuantidade = new System.Windows.Forms.Label();
            this.chkChopp = new System.Windows.Forms.CheckBox();
            this.chkRefeição = new System.Windows.Forms.CheckBox();
            this.chkPetiscos = new System.Windows.Forms.CheckBox();
            this.txtChopp = new System.Windows.Forms.TextBox();
            this.txtPetisco = new System.Windows.Forms.TextBox();
            this.txtRefeição = new System.Windows.Forms.TextBox();
            this.lblTotParcial = new System.Windows.Forms.Label();
            this.txtTotalParcial = new System.Windows.Forms.TextBox();
            this.lblTxServiço = new System.Windows.Forms.Label();
            this.txtTaxaServico = new System.Windows.Forms.TextBox();
            this.lblTotPagar = new System.Windows.Forms.Label();
            this.txtTotPagar = new System.Windows.Forms.TextBox();
            this.btnSair = new System.Windows.Forms.Button();
            this.btnFecharConta = new System.Windows.Forms.Button();
            this.btnCheck = new System.Windows.Forms.Button();
            this.SuspendLayout();
            // 
            // lblMesa
            // 
            this.lblMesa.AutoSize = true;
            this.lblMesa.Font = new System.Drawing.Font("Arial Narrow", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblMesa.Location = new System.Drawing.Point(5, 23);
            this.lblMesa.Name = "lblMesa";
            this.lblMesa.Size = new System.Drawing.Size(92, 23);
            this.lblMesa.TabIndex = 0;
            this.lblMesa.Text = "Nº da Mesa";
            this.lblMesa.Click += new System.EventHandler(this.label1_Click);
            // 
            // txtMesa
            // 
            this.txtMesa.Location = new System.Drawing.Point(103, 23);
            this.txtMesa.Name = "txtMesa";
            this.txtMesa.Size = new System.Drawing.Size(41, 20);
            this.txtMesa.TabIndex = 1;
            this.txtMesa.TextChanged += new System.EventHandler(this.textBox1_TextChanged);
            // 
            // lblPedidos
            // 
            this.lblPedidos.AutoSize = true;
            this.lblPedidos.Font = new System.Drawing.Font("Arial Narrow", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblPedidos.Location = new System.Drawing.Point(5, 77);
            this.lblPedidos.Name = "lblPedidos";
            this.lblPedidos.Size = new System.Drawing.Size(60, 20);
            this.lblPedidos.TabIndex = 2;
            this.lblPedidos.Text = "Pedidos";
            // 
            // lblQuantidade
            // 
            this.lblQuantidade.AutoSize = true;
            this.lblQuantidade.Font = new System.Drawing.Font("Arial Narrow", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblQuantidade.Location = new System.Drawing.Point(180, 77);
            this.lblQuantidade.Name = "lblQuantidade";
            this.lblQuantidade.Size = new System.Drawing.Size(80, 20);
            this.lblQuantidade.TabIndex = 3;
            this.lblQuantidade.Text = "Quantidade";
            // 
            // chkChopp
            // 
            this.chkChopp.AutoSize = true;
            this.chkChopp.Location = new System.Drawing.Point(9, 114);
            this.chkChopp.Name = "chkChopp";
            this.chkChopp.Size = new System.Drawing.Size(95, 17);
            this.chkChopp.TabIndex = 4;
            this.chkChopp.Text = "Chopp R$4,50";
            this.chkChopp.UseVisualStyleBackColor = true;
            // 
            // chkRefeição
            // 
            this.chkRefeição.AutoSize = true;
            this.chkRefeição.Location = new System.Drawing.Point(9, 186);
            this.chkRefeição.Name = "chkRefeição";
            this.chkRefeição.Size = new System.Drawing.Size(113, 17);
            this.chkRefeição.TabIndex = 5;
            this.chkRefeição.Text = "Refeição R$15,90";
            this.chkRefeição.UseVisualStyleBackColor = true;
            // 
            // chkPetiscos
            // 
            this.chkPetiscos.AutoSize = true;
            this.chkPetiscos.Location = new System.Drawing.Point(9, 150);
            this.chkPetiscos.Name = "chkPetiscos";
            this.chkPetiscos.Size = new System.Drawing.Size(107, 17);
            this.chkPetiscos.TabIndex = 6;
            this.chkPetiscos.Text = "Petiscos R$ 7,90";
            this.chkPetiscos.UseVisualStyleBackColor = true;
            // 
            // txtChopp
            // 
            this.txtChopp.Location = new System.Drawing.Point(184, 111);
            this.txtChopp.Name = "txtChopp";
            this.txtChopp.Size = new System.Drawing.Size(83, 20);
            this.txtChopp.TabIndex = 7;
            // 
            // txtPetisco
            // 
            this.txtPetisco.Location = new System.Drawing.Point(184, 147);
            this.txtPetisco.Name = "txtPetisco";
            this.txtPetisco.Size = new System.Drawing.Size(83, 20);
            this.txtPetisco.TabIndex = 8;
            // 
            // txtRefeição
            // 
            this.txtRefeição.Location = new System.Drawing.Point(184, 183);
            this.txtRefeição.Name = "txtRefeição";
            this.txtRefeição.Size = new System.Drawing.Size(83, 20);
            this.txtRefeição.TabIndex = 9;
            // 
            // lblTotParcial
            // 
            this.lblTotParcial.AutoSize = true;
            this.lblTotParcial.Font = new System.Drawing.Font("Arial Narrow", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblTotParcial.Location = new System.Drawing.Point(347, 77);
            this.lblTotParcial.Name = "lblTotParcial";
            this.lblTotParcial.Size = new System.Drawing.Size(87, 20);
            this.lblTotParcial.TabIndex = 10;
            this.lblTotParcial.Text = "Total Parcial";
            // 
            // txtTotalParcial
            // 
            this.txtTotalParcial.Location = new System.Drawing.Point(351, 103);
            this.txtTotalParcial.Name = "txtTotalParcial";
            this.txtTotalParcial.Size = new System.Drawing.Size(99, 20);
            this.txtTotalParcial.TabIndex = 11;
            // 
            // lblTxServiço
            // 
            this.lblTxServiço.AutoSize = true;
            this.lblTxServiço.Font = new System.Drawing.Font("Arial Narrow", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblTxServiço.Location = new System.Drawing.Point(347, 136);
            this.lblTxServiço.Name = "lblTxServiço";
            this.lblTxServiço.Size = new System.Drawing.Size(145, 20);
            this.lblTxServiço.TabIndex = 12;
            this.lblTxServiço.Text = "Taxa de Serviço (10%)";
            // 
            // txtTaxaServico
            // 
            this.txtTaxaServico.Location = new System.Drawing.Point(351, 162);
            this.txtTaxaServico.Name = "txtTaxaServico";
            this.txtTaxaServico.Size = new System.Drawing.Size(99, 20);
            this.txtTaxaServico.TabIndex = 13;
            // 
            // lblTotPagar
            // 
            this.lblTotPagar.AutoSize = true;
            this.lblTotPagar.Font = new System.Drawing.Font("Arial Narrow", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblTotPagar.Location = new System.Drawing.Point(347, 197);
            this.lblTotPagar.Name = "lblTotPagar";
            this.lblTotPagar.Size = new System.Drawing.Size(91, 20);
            this.lblTotPagar.TabIndex = 14;
            this.lblTotPagar.Text = "Total a Pagar";
            // 
            // txtTotPagar
            // 
            this.txtTotPagar.Location = new System.Drawing.Point(351, 223);
            this.txtTotPagar.Name = "txtTotPagar";
            this.txtTotPagar.Size = new System.Drawing.Size(99, 20);
            this.txtTotPagar.TabIndex = 15;
            // 
            // btnSair
            // 
            this.btnSair.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Zoom;
            this.btnSair.Location = new System.Drawing.Point(351, 317);
            this.btnSair.Name = "btnSair";
            this.btnSair.Size = new System.Drawing.Size(121, 103);
            this.btnSair.TabIndex = 18;
            this.btnSair.Text = "Sair";
            this.btnSair.UseVisualStyleBackColor = true;
            this.btnSair.Click += new System.EventHandler(this.button2_Click);
            // 
            // btnFecharConta
            // 
            this.btnFecharConta.BackgroundImage = global::Restaurante.Properties.Resources.PagaraConta;
            this.btnFecharConta.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Zoom;
            this.btnFecharConta.Location = new System.Drawing.Point(184, 317);
            this.btnFecharConta.Name = "btnFecharConta";
            this.btnFecharConta.Size = new System.Drawing.Size(130, 103);
            this.btnFecharConta.TabIndex = 17;
            this.btnFecharConta.UseVisualStyleBackColor = true;
            // 
            // btnCheck
            // 
            this.btnCheck.BackgroundImage = global::Restaurante.Properties.Resources.Check;
            this.btnCheck.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Zoom;
            this.btnCheck.Location = new System.Drawing.Point(31, 317);
            this.btnCheck.Name = "btnCheck";
            this.btnCheck.Size = new System.Drawing.Size(113, 103);
            this.btnCheck.TabIndex = 16;
            this.btnCheck.UseVisualStyleBackColor = true;
            // 
            // Pedidos
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(503, 437);
            this.Controls.Add(this.btnSair);
            this.Controls.Add(this.btnFecharConta);
            this.Controls.Add(this.btnCheck);
            this.Controls.Add(this.txtTotPagar);
            this.Controls.Add(this.lblTotPagar);
            this.Controls.Add(this.txtTaxaServico);
            this.Controls.Add(this.lblTxServiço);
            this.Controls.Add(this.txtTotalParcial);
            this.Controls.Add(this.lblTotParcial);
            this.Controls.Add(this.txtRefeição);
            this.Controls.Add(this.txtPetisco);
            this.Controls.Add(this.txtChopp);
            this.Controls.Add(this.chkPetiscos);
            this.Controls.Add(this.chkRefeição);
            this.Controls.Add(this.chkChopp);
            this.Controls.Add(this.lblQuantidade);
            this.Controls.Add(this.lblPedidos);
            this.Controls.Add(this.txtMesa);
            this.Controls.Add(this.lblMesa);
            this.Name = "Pedidos";
            this.Text = "Restaurante Bom Prato";
            this.Load += new System.EventHandler(this.Form1_Load);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label lblMesa;
        private System.Windows.Forms.TextBox txtMesa;
        private System.Windows.Forms.Label lblPedidos;
        private System.Windows.Forms.Label lblQuantidade;
        private System.Windows.Forms.CheckBox chkChopp;
        private System.Windows.Forms.CheckBox chkRefeição;
        private System.Windows.Forms.CheckBox chkPetiscos;
        private System.Windows.Forms.TextBox txtChopp;
        private System.Windows.Forms.TextBox txtPetisco;
        private System.Windows.Forms.TextBox txtRefeição;
        private System.Windows.Forms.Label lblTotParcial;
        private System.Windows.Forms.TextBox txtTotalParcial;
        private System.Windows.Forms.Label lblTxServiço;
        private System.Windows.Forms.TextBox txtTaxaServico;
        private System.Windows.Forms.Label lblTotPagar;
        private System.Windows.Forms.TextBox txtTotPagar;
        private System.Windows.Forms.Button btnCheck;
        private System.Windows.Forms.Button btnFecharConta;
        private System.Windows.Forms.Button btnSair;
    }
}

