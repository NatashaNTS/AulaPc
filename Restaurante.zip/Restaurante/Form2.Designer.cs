﻿namespace Restaurante
{
    partial class Form2
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.groupBox1 = new System.Windows.Forms.GroupBox();
            this.rbDinheiro = new System.Windows.Forms.RadioButton();
            this.rbCDebito = new System.Windows.Forms.RadioButton();
            this.rbCCredito = new System.Windows.Forms.RadioButton();
            this.groupBox2 = new System.Windows.Forms.GroupBox();
            this.rbBAmerican = new System.Windows.Forms.RadioButton();
            this.rbBMasterCard = new System.Windows.Forms.RadioButton();
            this.rbBVisa = new System.Windows.Forms.RadioButton();
            this.groupBox3 = new System.Windows.Forms.GroupBox();
            this.label1 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.button1 = new System.Windows.Forms.Button();
            this.txtVaSerPago = new System.Windows.Forms.TextBox();
            this.txtVaRecebido = new System.Windows.Forms.TextBox();
            this.txtTroco = new System.Windows.Forms.TextBox();
            this.groupBox1.SuspendLayout();
            this.groupBox2.SuspendLayout();
            this.groupBox3.SuspendLayout();
            this.SuspendLayout();
            // 
            // groupBox1
            // 
            this.groupBox1.Controls.Add(this.rbCCredito);
            this.groupBox1.Controls.Add(this.rbCDebito);
            this.groupBox1.Controls.Add(this.rbDinheiro);
            this.groupBox1.Font = new System.Drawing.Font("Arial Narrow", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.groupBox1.Location = new System.Drawing.Point(12, 12);
            this.groupBox1.Name = "groupBox1";
            this.groupBox1.Size = new System.Drawing.Size(458, 65);
            this.groupBox1.TabIndex = 0;
            this.groupBox1.TabStop = false;
            this.groupBox1.Text = "Forma de Pagamento";
            this.groupBox1.Enter += new System.EventHandler(this.groupBox1_Enter);
            // 
            // rbDinheiro
            // 
            this.rbDinheiro.AutoSize = true;
            this.rbDinheiro.Location = new System.Drawing.Point(21, 29);
            this.rbDinheiro.Name = "rbDinheiro";
            this.rbDinheiro.Size = new System.Drawing.Size(76, 24);
            this.rbDinheiro.TabIndex = 0;
            this.rbDinheiro.TabStop = true;
            this.rbDinheiro.Text = "Dinheiro";
            this.rbDinheiro.UseVisualStyleBackColor = true;
            this.rbDinheiro.CheckedChanged += new System.EventHandler(this.radioButton1_CheckedChanged);
            // 
            // rbCDebito
            // 
            this.rbCDebito.AutoSize = true;
            this.rbCDebito.Location = new System.Drawing.Point(139, 29);
            this.rbCDebito.Name = "rbCDebito";
            this.rbCDebito.Size = new System.Drawing.Size(128, 24);
            this.rbCDebito.TabIndex = 1;
            this.rbCDebito.TabStop = true;
            this.rbCDebito.Text = "Cartão de Débito";
            this.rbCDebito.UseVisualStyleBackColor = true;
            this.rbCDebito.CheckedChanged += new System.EventHandler(this.radioButton2_CheckedChanged);
            // 
            // rbCCredito
            // 
            this.rbCCredito.AutoSize = true;
            this.rbCCredito.Location = new System.Drawing.Point(297, 29);
            this.rbCCredito.Name = "rbCCredito";
            this.rbCCredito.Size = new System.Drawing.Size(132, 24);
            this.rbCCredito.TabIndex = 2;
            this.rbCCredito.TabStop = true;
            this.rbCCredito.Text = "Cartão de Crédito";
            this.rbCCredito.UseVisualStyleBackColor = true;
            // 
            // groupBox2
            // 
            this.groupBox2.Controls.Add(this.rbBAmerican);
            this.groupBox2.Controls.Add(this.rbBMasterCard);
            this.groupBox2.Controls.Add(this.rbBVisa);
            this.groupBox2.Font = new System.Drawing.Font("Arial Narrow", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.groupBox2.Location = new System.Drawing.Point(12, 178);
            this.groupBox2.Name = "groupBox2";
            this.groupBox2.Size = new System.Drawing.Size(458, 65);
            this.groupBox2.TabIndex = 1;
            this.groupBox2.TabStop = false;
            this.groupBox2.Text = "Bandeira do Cartão";
            // 
            // rbBAmerican
            // 
            this.rbBAmerican.AutoSize = true;
            this.rbBAmerican.Location = new System.Drawing.Point(297, 29);
            this.rbBAmerican.Name = "rbBAmerican";
            this.rbBAmerican.Size = new System.Drawing.Size(137, 24);
            this.rbBAmerican.TabIndex = 2;
            this.rbBAmerican.TabStop = true;
            this.rbBAmerican.Text = "American Express";
            this.rbBAmerican.UseVisualStyleBackColor = true;
            // 
            // rbBMasterCard
            // 
            this.rbBMasterCard.AutoSize = true;
            this.rbBMasterCard.Location = new System.Drawing.Point(139, 29);
            this.rbBMasterCard.Name = "rbBMasterCard";
            this.rbBMasterCard.Size = new System.Drawing.Size(95, 24);
            this.rbBMasterCard.TabIndex = 1;
            this.rbBMasterCard.TabStop = true;
            this.rbBMasterCard.Text = "MasterCard";
            this.rbBMasterCard.UseVisualStyleBackColor = true;
            // 
            // rbBVisa
            // 
            this.rbBVisa.AutoSize = true;
            this.rbBVisa.Location = new System.Drawing.Point(21, 29);
            this.rbBVisa.Name = "rbBVisa";
            this.rbBVisa.Size = new System.Drawing.Size(53, 24);
            this.rbBVisa.TabIndex = 0;
            this.rbBVisa.TabStop = true;
            this.rbBVisa.Text = "Visa";
            this.rbBVisa.UseVisualStyleBackColor = true;
            // 
            // groupBox3
            // 
            this.groupBox3.Controls.Add(this.txtTroco);
            this.groupBox3.Controls.Add(this.txtVaRecebido);
            this.groupBox3.Controls.Add(this.txtVaSerPago);
            this.groupBox3.Controls.Add(this.label3);
            this.groupBox3.Controls.Add(this.label2);
            this.groupBox3.Controls.Add(this.label1);
            this.groupBox3.Font = new System.Drawing.Font("Arial Narrow", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.groupBox3.Location = new System.Drawing.Point(476, 12);
            this.groupBox3.Name = "groupBox3";
            this.groupBox3.Size = new System.Drawing.Size(312, 175);
            this.groupBox3.TabIndex = 2;
            this.groupBox3.TabStop = false;
            this.groupBox3.Text = "Dados de Pagamento";
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(23, 33);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(110, 20);
            this.label1.TabIndex = 0;
            this.label1.Text = "Valor a ser Pago";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(23, 82);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(103, 20);
            this.label2.TabIndex = 1;
            this.label2.Text = "Valor Recebido";
            this.label2.Click += new System.EventHandler(this.label2_Click);
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Location = new System.Drawing.Point(23, 129);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(43, 20);
            this.label3.TabIndex = 2;
            this.label3.Text = "Troco";
            this.label3.Click += new System.EventHandler(this.label3_Click);
            // 
            // button1
            // 
            this.button1.Location = new System.Drawing.Point(550, 203);
            this.button1.Name = "button1";
            this.button1.Size = new System.Drawing.Size(188, 34);
            this.button1.TabIndex = 3;
            this.button1.Text = "Finalizar";
            this.button1.UseVisualStyleBackColor = true;
            // 
            // txtVaSerPago
            // 
            this.txtVaSerPago.Location = new System.Drawing.Point(139, 30);
            this.txtVaSerPago.Name = "txtVaSerPago";
            this.txtVaSerPago.Size = new System.Drawing.Size(151, 26);
            this.txtVaSerPago.TabIndex = 4;
            this.txtVaSerPago.TextChanged += new System.EventHandler(this.textBox1_TextChanged);
            // 
            // txtVaRecebido
            // 
            this.txtVaRecebido.Location = new System.Drawing.Point(139, 79);
            this.txtVaRecebido.Name = "txtVaRecebido";
            this.txtVaRecebido.Size = new System.Drawing.Size(151, 26);
            this.txtVaRecebido.TabIndex = 5;
            // 
            // txtTroco
            // 
            this.txtTroco.Location = new System.Drawing.Point(139, 126);
            this.txtTroco.Name = "txtTroco";
            this.txtTroco.Size = new System.Drawing.Size(151, 26);
            this.txtTroco.TabIndex = 6;
            // 
            // Form2
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(805, 255);
            this.Controls.Add(this.button1);
            this.Controls.Add(this.groupBox3);
            this.Controls.Add(this.groupBox2);
            this.Controls.Add(this.groupBox1);
            this.Name = "Form2";
            this.Text = "Fechamento";
            this.groupBox1.ResumeLayout(false);
            this.groupBox1.PerformLayout();
            this.groupBox2.ResumeLayout(false);
            this.groupBox2.PerformLayout();
            this.groupBox3.ResumeLayout(false);
            this.groupBox3.PerformLayout();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.GroupBox groupBox1;
        private System.Windows.Forms.RadioButton rbCCredito;
        private System.Windows.Forms.RadioButton rbCDebito;
        private System.Windows.Forms.RadioButton rbDinheiro;
        private System.Windows.Forms.GroupBox groupBox2;
        private System.Windows.Forms.RadioButton rbBAmerican;
        private System.Windows.Forms.RadioButton rbBMasterCard;
        private System.Windows.Forms.RadioButton rbBVisa;
        private System.Windows.Forms.GroupBox groupBox3;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Button button1;
        private System.Windows.Forms.TextBox txtVaSerPago;
        private System.Windows.Forms.TextBox txtTroco;
        private System.Windows.Forms.TextBox txtVaRecebido;
    }
}